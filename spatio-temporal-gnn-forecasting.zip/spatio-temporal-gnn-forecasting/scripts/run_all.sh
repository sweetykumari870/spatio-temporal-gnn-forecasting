#!/usr/bin/env bash
# Train the proposed model, its ablation and all baselines for several seeds.
# usage: bash scripts/run_all.sh configs/metr_la.yaml
set -euo pipefail
CFG=${1:-configs/synthetic.yaml}
for seed in 0 1 2; do
  for model in stgnn stgnn_fixed lstm gru transformer; do
    python -m stgnn.train --config "$CFG" --model "$model" --seed "$seed"
  done
done
python scripts/aggregate_results.py --runs runs
