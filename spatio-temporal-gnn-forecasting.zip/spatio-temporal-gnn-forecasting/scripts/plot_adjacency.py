"""Visualise the learned adaptive adjacency of a trained STGNN checkpoint next to the road-graph adjacency."""
import argparse

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

from stgnn.data import build_data
from stgnn.models import build_model
from stgnn.utils import load_config

ap = argparse.ArgumentParser()
ap.add_argument("--run", required=True, help="run directory containing config.yaml and best.pt")
ap.add_argument("--out", default="adjacency.png")
a = ap.parse_args()
cfg = load_config(f"{a.run}/config.yaml")
data = build_data(cfg)
model = build_model("stgnn", cfg, data.num_nodes, data.edge_index, data.edge_weight)
model.load_state_dict(torch.load(f"{a.run}/best.pt", map_location="cpu"))
adj = model.learned_adjacency()[-1].detach()
fig, ax = plt.subplots(1, 2, figsize=(10, 4.5))
ax[0].imshow(data.adj, cmap="viridis"); ax[0].set_title("graph adjacency (given)")
ax[1].imshow(adj, cmap="viridis"); ax[1].set_title("learned adaptive adjacency")
plt.tight_layout(); plt.savefig(a.out, dpi=150); print("wrote", a.out)
