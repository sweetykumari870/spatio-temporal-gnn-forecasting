"""Aggregate runs/*/test_metrics.json into a mean +- std markdown table."""
import argparse
import glob
import json
import os

import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--runs", default="runs")
ap.add_argument("--out", default="results.md")
a = ap.parse_args()

rows = [json.load(open(p)) for p in glob.glob(os.path.join(a.runs, "*", "test_metrics.json"))]
df = pd.DataFrame(rows)
cols = [c for c in ["MAE@3", "MAE@6", "MAE@12", "RMSE@3", "RMSE@6", "RMSE@12", "MAPE@3", "MAPE@6", "MAPE@12", "MAE"]
        if c in df]
g = df.groupby("model")
mean, std = g[cols].mean(), g[cols].std().fillna(0)
tab = mean.round(3).astype(str) + " +- " + std.round(3).astype(str)
tab.insert(0, "params", g["params"].first())
tab.insert(1, "seeds", g.size())
md = tab.to_markdown() if hasattr(tab, "to_markdown") else tab.to_string()
open(a.out, "w").write(md + "\n")
print(md)
