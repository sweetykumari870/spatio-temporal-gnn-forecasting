import numpy as np
import torch

from stgnn.data import adjacency_to_edges, build_data, make_synthetic
from stgnn.metrics import all_metrics, masked_mae, masked_mape
from stgnn.models import STGNN, build_model
from stgnn.train import main

CFG = {
    "data": {"dataset": "synthetic", "input_len": 12, "horizon": 6, "batch_size": 16, "num_workers": 0,
             "synthetic": {"num_nodes": 12, "num_steps": 700, "seed": 0}},
    "model": {"channels": 16, "num_blocks": 2, "cheb_k": 2, "heads": 2, "dropout": 0.0},
    "train": {"epochs": 2, "lr": 0.003, "patience": 5, "amp": False},
}


def test_masked_metrics_ignore_missing():
    t = torch.tensor([[1.0, 0.0, 3.0]])
    p = torch.tensor([[2.0, 99.0, 3.0]])
    assert abs(masked_mae(p, t).item() - 0.5) < 1e-6
    assert masked_mape(p, t).item() > 0
    m = all_metrics(p.reshape(1, 1, 3), t.reshape(1, 1, 3), horizons=(1,))
    assert abs(m["MAE@1"] - 0.5) < 1e-6


def test_windows_and_shapes():
    data = build_data(CFG)
    x, y = next(iter(data.train))
    assert x.shape[1:] == (12, 12, 2) and y.shape[1:] == (6, 12)
    # chronological, non-overlapping splits
    assert data.train.dataset.starts[-1] < data.test.dataset.starts[0]


def test_model_shapes_and_permutation_equivariance():
    data = build_data(CFG)
    model = STGNN(data.num_nodes, data.edge_index, data.edge_weight, input_len=12, horizon=6, channels=16,
                  num_blocks=2, cheb_k=2, heads=2, dropout=0.0, adaptive=False).eval()
    x, _ = next(iter(data.train))
    out = model(x)
    assert out.shape == (x.shape[0], 6, data.num_nodes)
    perm = torch.randperm(data.num_nodes)
    inv = torch.argsort(perm)
    ei = inv[data.edge_index]  # relabel nodes: new index of old node j is inv[j]
    model_p = STGNN(data.num_nodes, ei, data.edge_weight, input_len=12, horizon=6, channels=16, num_blocks=2,
                    cheb_k=2, heads=2, dropout=0.0, adaptive=False).eval()
    model_p.load_state_dict({k: v for k, v in model.state_dict().items() if "edge_index" not in k}, strict=False)
    out_p = model_p(x[:, :, perm])
    assert torch.allclose(out[:, :, perm], out_p, atol=1e-4)


def test_all_models_build_and_forward():
    data = build_data(CFG)
    x, _ = next(iter(data.train))
    for name in ["stgnn", "stgnn_fixed", "lstm", "gru", "transformer"]:
        m = build_model(name, CFG, data.num_nodes, data.edge_index, data.edge_weight)
        assert m(x).shape == (x.shape[0], 6, data.num_nodes), name


def test_adaptive_adjacency_row_stochastic():
    data = build_data(CFG)
    m = build_model("stgnn", CFG, data.num_nodes, data.edge_index, data.edge_weight)
    for a in m.learned_adjacency():
        assert torch.allclose(a.sum(1), torch.ones(data.num_nodes), atol=1e-5)


def test_end_to_end_training(tmp_path):
    import yaml
    p = tmp_path / "c.yaml"
    p.write_text(yaml.safe_dump(CFG))
    m = main(["--config", str(p), "--model", "stgnn", "--seed", "1", "--run-dir", str(tmp_path / "runs")])
    assert np.isfinite(m["MAE"]) and "MAE@6" in m
