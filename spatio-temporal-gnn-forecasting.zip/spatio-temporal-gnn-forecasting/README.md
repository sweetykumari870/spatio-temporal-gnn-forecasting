# Spatio-Temporal Forecasting with Graph Neural Networks

PyTorch / PyTorch Geometric implementation of a spatio-temporal GNN for large-scale traffic-style time-series
forecasting (default: 12 steps in -> 12 steps out on a sensor network), with an **adaptive learned adjacency**
variant, reproducible experiment tracking, and LSTM / GRU / Transformer baselines.

**Stack:** Python, PyTorch, PyTorch Geometric.

> **Before publishing:** the architecture follows the gated-temporal-conv + graph-convolution family
> (STGCN, Graph WaveNet) plus temporal attention. In the "Reference" section below, replace the placeholder with
> the exact conference paper you reimplemented and note any deviations.

## Model

```
input (B, T, N, [speed, time-of-day])
  -> Linear embedding
  -> L x STBlock:
       gated causal temporal conv (GLU, dilated)
       spatial block = Chebyshev spectral filter (K-th order poly. of the scaled graph Laplacian, PyG ChebConv)
                     + adaptive diffusion over A_adp = softmax(ReLU(E1 E2^T))        <- proposed variant
       temporal multi-head self-attention
       residual + LayerNorm
  -> MLP head -> (B, horizon, N)
```

Geometric deep-learning ideas used / tested:

* **Graph-Laplacian spectral filters:** `ChebConv` approximates spectral filtering with Chebyshev polynomials of
  `L_hat = 2L/lambda_max - I`, avoiding eigendecomposition.
* **Message passing:** the same layer is a K-hop sparse neighbourhood aggregation over `edge_index`.
* **Permutation equivariance:** relabelling the nodes permutes the outputs identically - verified in
  `tests/test_stgnn.py::test_model_shapes_and_permutation_equivariance`.
* **Adaptive learned adjacency:** node embeddings `E1, E2 in R^{N x d}` yield a row-stochastic learned graph per
  block that can capture dependencies absent from the road graph; `stgnn_fixed` is the ablation without it.

Baselines: node-shared **LSTM**, **GRU**, temporal **Transformer** (no spatial information).
Metrics: masked **MAE, RMSE, MAPE** (zeros = missing readings are ignored), reported at horizons 3/6/12 steps
(15/30/60 min at 5-min sampling).

## Engineering

* **Mixed precision** (`train.amp`, fp16 autocast + GradScaler on CUDA) and gradient clipping.
* **Efficient sparse-graph batching:** the road graph is shared by all samples, so a batch of `B*T` graph signals
  is passed to PyG as a dense feature tensor `(B*T, N, C)` over a single `edge_index` - no per-sample graph copies.
* **Lazy windowing:** sliding windows are sliced on the fly (`WindowDataset`); no `O(T x window)` memory blow-up.
* **Reproducibility:** YAML configs with command-line overrides, explicit seeds (`--seed`), optional deterministic
  mode, and every run directory stores `config.yaml`, `env.json` (torch/CUDA/GPU/git hash), `log.jsonl`
  (per-epoch metrics), `best.pt` and `test_metrics.json`.

## Setup

```bash
git clone https://github.com/<your-username>/spatio-temporal-gnn-forecasting.git
cd spatio-temporal-gnn-forecasting
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,metr]"
pytest -q
```

## Data

* **Smoke test (no download):** `configs/synthetic.yaml` generates a random geometric sensor graph with daily
  periodicity, graph-diffused noise and 3% missing readings.
* **METR-LA / PEMS-BAY:** obtain the DCRNN-format files from the public DCRNN / Graph WaveNet data releases and
  place them as `data/metr-la.h5` (or `data/pems-bay.h5`) and `data/adj_mx.pkl`. Chronological 70/10/20 split,
  z-score normalisation on training data.
* **Your own data:** `data/data.npz` with `x` (T, N) and `adj` (N, N), `dataset: npz` in the config.

## Run

```bash
python -m stgnn.train --config configs/synthetic.yaml --model stgnn --seed 0
python -m stgnn.train --config configs/metr_la.yaml  --model stgnn --seed 0 --set train.epochs=100

bash scripts/run_all.sh configs/metr_la.yaml       # all models x 3 seeds, then aggregates
python scripts/aggregate_results.py                # -> results.md (mean +- std over seeds)
python scripts/plot_adjacency.py --run runs/<run>  # given vs learned adjacency
```

## Results

Fill in after running on your hardware (3 seeds, mean +- std):

| Model | Params | MAE@3 | MAE@6 | MAE@12 | RMSE@12 | MAPE@12 |
|---|---|---|---|---|---|---|
| LSTM | _fill_ | | | | | |
| GRU | _fill_ | | | | | |
| Transformer | _fill_ | | | | | |
| STGNN (fixed graph) | _fill_ | | | | | |
| **STGNN (adaptive adjacency)** | _fill_ | | | | | |

## Reference

_Add the paper you reimplemented here (authors, title, venue, year) and list deviations from the original._

## Layout

```
src/stgnn/  data.py models.py metrics.py train.py utils.py
configs/    synthetic.yaml metr_la.yaml pems_bay.yaml
scripts/    run_all.sh aggregate_results.py plot_adjacency.py
tests/      metrics, windowing, shapes, permutation equivariance, adjacency, end-to-end training
```

## License
MIT
