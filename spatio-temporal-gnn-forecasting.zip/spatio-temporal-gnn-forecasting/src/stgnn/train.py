"""Train / evaluate a forecaster.

    python -m stgnn.train --config configs/synthetic.yaml --model stgnn --seed 0 [--set train.epochs=5]
"""
from __future__ import annotations

import argparse
import time

import torch

from .data import build_data
from .metrics import all_metrics, masked_mae
from .models import build_model
from .utils import RunLogger, load_config, set_seed


@torch.no_grad()
def predict(model, loader, scaler, device, amp):
    model.eval()
    preds, ys = [], []
    for x, y in loader:
        x = x.to(device, non_blocking=True)
        with torch.autocast(device.type, dtype=torch.float16, enabled=amp):
            p = model(x)
        preds.append(scaler.inverse(p.float()).cpu())
        ys.append(y)
    return torch.cat(preds), torch.cat(ys)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--model", default="stgnn", choices=["stgnn", "stgnn_fixed", "lstm", "gru", "transformer"])
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--set", nargs="*", default=[], help="config overrides, e.g. train.epochs=5")
    ap.add_argument("--run-dir", default="runs")
    args = ap.parse_args(argv)

    cfg = load_config(args.config, args.set)
    set_seed(args.seed, cfg["train"].get("deterministic", False))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    amp = bool(cfg["train"].get("amp", True)) and device.type == "cuda"

    data = build_data(cfg)
    model = build_model(args.model, cfg, data.num_nodes, data.edge_index, data.edge_weight).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    logger = RunLogger(args.run_dir, f"{cfg['data']['dataset']}_{args.model}_seed{args.seed}",
                       {**cfg, "model_name": args.model, "seed": args.seed, "n_params": n_params})
    logger.log(event="start", model=args.model, params=n_params, device=str(device), amp=amp)

    t = cfg["train"]
    opt = torch.optim.AdamW(model.parameters(), lr=t["lr"], weight_decay=t.get("weight_decay", 1e-4))
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, t["epochs"])
    scaler_amp = torch.amp.GradScaler("cuda", enabled=amp)
    best, bad, ckpt = float("inf"), 0, f"{logger.dir}/best.pt"

    for epoch in range(1, t["epochs"] + 1):
        model.train()
        t0, tot, n = time.time(), 0.0, 0
        for x, y in data.train:
            x, y = x.to(device, non_blocking=True), y.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            with torch.autocast(device.type, dtype=torch.float16, enabled=amp):
                pred = model(x)
            loss = masked_mae(data.scaler.inverse(pred.float()), y)
            scaler_amp.scale(loss).backward()
            scaler_amp.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), t.get("clip", 5.0))
            scaler_amp.step(opt)
            scaler_amp.update()
            tot += loss.item() * x.size(0)
            n += x.size(0)
        sched.step()
        pv, yv = predict(model, data.val, data.scaler, device, amp)
        val_mae = masked_mae(pv, yv).item()
        logger.log(epoch=epoch, train_mae=tot / n, val_mae=val_mae, lr=sched.get_last_lr()[0],
                   sec=time.time() - t0)
        if val_mae < best:
            best, bad = val_mae, 0
            torch.save(model.state_dict(), ckpt)
        else:
            bad += 1
            if bad >= t.get("patience", 10):
                logger.log(event="early_stop", epoch=epoch)
                break

    model.load_state_dict(torch.load(ckpt, map_location=device))
    pt, yt = predict(model, data.test, data.scaler, device, amp)
    metrics = all_metrics(pt, yt, horizons=tuple(h for h in (3, 6, 12) if h <= cfg["data"]["horizon"]))
    metrics.update(model=args.model, seed=args.seed, params=n_params, best_val_mae=best)
    logger.save_json("test_metrics.json", metrics)
    logger.log(event="test", **metrics)
    return metrics


if __name__ == "__main__":
    main()
