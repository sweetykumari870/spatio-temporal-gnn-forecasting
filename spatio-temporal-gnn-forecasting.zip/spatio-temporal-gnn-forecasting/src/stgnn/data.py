"""Data loading, graph construction and windowing.

Supported sources
-----------------
* ``synthetic``: generated on the fly (smoke tests, CI, quick experiments)
* ``metr-la`` / ``pems-bay``: DCRNN-format files ``<data_dir>/<name>.h5`` (pandas HDF, rows=time, cols=sensors)
  and ``<data_dir>/adj_mx.pkl`` (pickle: sensor_ids, sensor_id_to_ind, adj_mx)
* ``npz``: ``<data_dir>/data.npz`` with ``x`` (T, N) speeds and ``adj`` (N, N) weighted adjacency
"""
from __future__ import annotations

import os
import pickle
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

STEPS_PER_DAY = 288  # 5-minute sampling


# --------------------------------------------------------------------------- #
# raw data
# --------------------------------------------------------------------------- #
def make_synthetic(num_nodes: int = 30, num_steps: int = STEPS_PER_DAY * 20, seed: int = 0,
                   missing_rate: float = 0.03) -> Tuple[np.ndarray, np.ndarray]:
    """Daily pattern + graph-diffusing AR noise on a random geometric graph. Returns x (T,N), adj (N,N)."""
    rng = np.random.default_rng(seed)
    pos = rng.random((num_nodes, 2))
    d = np.linalg.norm(pos[:, None] - pos[None], axis=-1)
    adj = np.exp(-(d / 0.25) ** 2)
    adj[adj < 0.1] = 0.0
    np.fill_diagonal(adj, 1.0)
    a_norm = adj / adj.sum(1, keepdims=True)
    t = np.arange(num_steps)
    phase = rng.uniform(0, 2 * np.pi, num_nodes)
    base = 55 - 18 * np.sin(2 * np.pi * t[:, None] / STEPS_PER_DAY + phase[None]) ** 2
    noise = np.zeros((num_steps, num_nodes))
    eps = rng.normal(0, 1.5, (num_steps, num_nodes))
    for i in range(1, num_steps):
        noise[i] = 0.85 * (a_norm @ noise[i - 1]) + eps[i]
    x = np.clip(base + noise, 3.0, 80.0)
    x[rng.random(x.shape) < missing_rate] = 0.0
    return x.astype(np.float32), adj.astype(np.float32)


def load_dcrnn_format(data_dir: str, name: str) -> Tuple[np.ndarray, np.ndarray]:
    import pandas as pd
    df = pd.read_hdf(os.path.join(data_dir, f"{name}.h5"))
    with open(os.path.join(data_dir, "adj_mx.pkl"), "rb") as f:
        _, _, adj = pickle.load(f, encoding="latin1")
    return df.values.astype(np.float32), np.asarray(adj, dtype=np.float32)


def load_raw(dataset: str, data_dir: str, **kw) -> Tuple[np.ndarray, np.ndarray]:
    if dataset == "synthetic":
        return make_synthetic(**kw)
    if dataset in ("metr-la", "pems-bay"):
        return load_dcrnn_format(data_dir, dataset)
    if dataset == "npz":
        z = np.load(os.path.join(data_dir, "data.npz"))
        return z["x"].astype(np.float32), z["adj"].astype(np.float32)
    raise ValueError(f"unknown dataset {dataset}")


# --------------------------------------------------------------------------- #
# graph
# --------------------------------------------------------------------------- #
def adjacency_to_edges(adj: np.ndarray, threshold: float = 0.0):
    """Dense weighted adjacency -> (edge_index [2,E], edge_weight [E]) for PyG."""
    src, dst = np.nonzero(adj > threshold)
    ei = torch.tensor(np.stack([src, dst]), dtype=torch.long)
    ew = torch.tensor(adj[src, dst], dtype=torch.float32)
    return ei, ew


# --------------------------------------------------------------------------- #
# windowing
# --------------------------------------------------------------------------- #
class StandardScaler:
    def __init__(self, mean: float, std: float):
        self.mean, self.std = float(mean), float(std)

    def transform(self, x):
        return (x - self.mean) / self.std

    def inverse(self, x):
        return x * self.std + self.mean


class WindowDataset(Dataset):
    """Lazy sliding windows: x (T_in, N, F=2: normalised speed, time-of-day), y (T_out, N) raw speed."""

    def __init__(self, x_norm: np.ndarray, y_raw: np.ndarray, tod: np.ndarray, starts: np.ndarray,
                 t_in: int, t_out: int):
        self.x, self.y, self.tod = x_norm, y_raw, tod
        self.starts, self.t_in, self.t_out = starts, t_in, t_out

    def __len__(self):
        return len(self.starts)

    def __getitem__(self, i):
        s = self.starts[i]
        a, b = s + self.t_in, s + self.t_in + self.t_out
        speed = self.x[s:a]
        tod = np.repeat(self.tod[s:a, None], self.x.shape[1], axis=1)
        x = np.stack([speed, tod], axis=-1)
        return torch.from_numpy(x.astype(np.float32)), torch.from_numpy(self.y[a:b].astype(np.float32))


@dataclass
class Bundle:
    train: DataLoader
    val: DataLoader
    test: DataLoader
    scaler: StandardScaler
    edge_index: torch.Tensor
    edge_weight: torch.Tensor
    adj: np.ndarray
    num_nodes: int


def build_data(cfg: dict) -> Bundle:
    d = cfg["data"]
    x, adj = load_raw(d["dataset"], d.get("data_dir", "data"), **d.get("synthetic", {}))
    T, N = x.shape
    t_in, t_out = d["input_len"], d["horizon"]
    n_train, n_val = int(0.7 * T), int(0.1 * T)
    valid = x[:n_train][x[:n_train] != 0]
    scaler = StandardScaler(valid.mean(), valid.std())
    x_norm = scaler.transform(x) * (x != 0)  # missing -> 0 after normalisation
    tod = (np.arange(T) % STEPS_PER_DAY) / STEPS_PER_DAY

    def starts(lo, hi):
        return np.arange(lo, hi - t_in - t_out + 1)

    sets = [WindowDataset(x_norm, x, tod, starts(lo, hi), t_in, t_out)
            for lo, hi in [(0, n_train), (n_train, n_train + n_val), (n_train + n_val, T)]]
    bs, nw = d.get("batch_size", 64), d.get("num_workers", 2)
    pin = torch.cuda.is_available()
    loaders = [DataLoader(s, bs, shuffle=(i == 0), num_workers=nw, pin_memory=pin, drop_last=False)
               for i, s in enumerate(sets)]
    ei, ew = adjacency_to_edges(adj)
    return Bundle(*loaders, scaler, ei, ew, adj, N)
