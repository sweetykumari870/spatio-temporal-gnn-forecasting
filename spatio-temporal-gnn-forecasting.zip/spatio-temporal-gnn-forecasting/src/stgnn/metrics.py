"""Masked forecasting metrics (entries equal to ``null_val`` are missing sensor readings)."""
import torch


def _mask(target: torch.Tensor, null_val: float) -> torch.Tensor:
    m = (target != null_val).float()
    return m / m.mean().clamp_min(1e-8)


def masked_mae(pred, target, null_val: float = 0.0):
    m = _mask(target, null_val)
    return (torch.abs(pred - target) * m).mean()


def masked_rmse(pred, target, null_val: float = 0.0):
    m = _mask(target, null_val)
    return torch.sqrt(((pred - target) ** 2 * m).mean())


def masked_mape(pred, target, null_val: float = 0.0, eps: float = 1e-5):
    m = _mask(target, null_val)
    return (torch.abs(pred - target) / target.abs().clamp_min(eps) * m).mean() * 100.0


def all_metrics(pred, target, horizons=(3, 6, 12), null_val: float = 0.0):
    """pred/target: (B, T_out, N) in original units. Returns dict with overall and per-horizon values."""
    out = {"MAE": masked_mae(pred, target, null_val).item(),
           "RMSE": masked_rmse(pred, target, null_val).item(),
           "MAPE": masked_mape(pred, target, null_val).item()}
    for h in horizons:
        if h <= pred.shape[1]:
            p, t = pred[:, h - 1], target[:, h - 1]
            out[f"MAE@{h}"] = masked_mae(p, t, null_val).item()
            out[f"RMSE@{h}"] = masked_rmse(p, t, null_val).item()
            out[f"MAPE@{h}"] = masked_mape(p, t, null_val).item()
    return out
