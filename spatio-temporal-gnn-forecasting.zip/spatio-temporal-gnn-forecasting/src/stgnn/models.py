"""STGNN (spatial-temporal GNN) and sequence baselines.

STGNN block (input/output (B, T, N, C)):
    gated causal temporal conv (GLU)  ->  spatial block  ->  temporal self-attention  ->  residual + LayerNorm
Spatial block = Chebyshev *spectral* graph filter on the fixed graph (K-order polynomial of the scaled
Laplacian, PyG ``ChebConv``, equivariant to node permutations) + optional *adaptive* diffusion over a learned
adjacency softmax(ReLU(E1 E2^T)) (Graph-WaveNet-style) that can discover dependencies missing from the road graph.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import ChebConv


class GatedTemporalConv(nn.Module):
    def __init__(self, channels: int, kernel_size: int = 3, dilation: int = 1):
        super().__init__()
        self.pad = (kernel_size - 1) * dilation
        self.conv = nn.Conv2d(channels, 2 * channels, (1, kernel_size), dilation=(1, dilation))

    def forward(self, x):  # (B,T,N,C)
        h = x.permute(0, 3, 2, 1)  # (B,C,N,T)
        h = self.conv(F.pad(h, (self.pad, 0)))
        a, b = h.chunk(2, dim=1)
        return (a * torch.sigmoid(b)).permute(0, 3, 2, 1)


class SpatialBlock(nn.Module):
    def __init__(self, channels: int, num_nodes: int, cheb_k: int = 3, adaptive: bool = True,
                 embed_dim: int = 10):
        super().__init__()
        self.cheb = ChebConv(channels, channels, K=cheb_k, normalization="sym")
        self.adaptive = adaptive
        if adaptive:
            self.e1 = nn.Parameter(torch.randn(num_nodes, embed_dim) * 0.1)
            self.e2 = nn.Parameter(torch.randn(num_nodes, embed_dim) * 0.1)
            self.adp_lin = nn.Linear(channels, channels)

    def learned_adjacency(self):
        return F.softmax(F.relu(self.e1 @ self.e2.t()), dim=1)

    def forward(self, x, edge_index, edge_weight):  # (B,T,N,C)
        B, T, N, C = x.shape
        h = self.cheb(x.reshape(B * T, N, C), edge_index, edge_weight).reshape(B, T, N, C)
        if self.adaptive:
            a = self.learned_adjacency().to(x.dtype)
            h = h + self.adp_lin(torch.einsum("nm,btmc->btnc", a, x))
        return F.relu(h)


class TemporalAttention(nn.Module):
    def __init__(self, channels: int, heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.attn = nn.MultiheadAttention(channels, heads, dropout=dropout, batch_first=True)

    def forward(self, x):
        B, T, N, C = x.shape
        h = x.permute(0, 2, 1, 3).reshape(B * N, T, C)
        h, _ = self.attn(h, h, h, need_weights=False)
        return h.reshape(B, N, T, C).permute(0, 2, 1, 3)


class STBlock(nn.Module):
    def __init__(self, channels, num_nodes, cheb_k, adaptive, heads, dropout, kernel_size, dilation):
        super().__init__()
        self.t = GatedTemporalConv(channels, kernel_size, dilation)
        self.s = SpatialBlock(channels, num_nodes, cheb_k, adaptive)
        self.a = TemporalAttention(channels, heads, dropout)
        self.norm = nn.LayerNorm(channels)
        self.drop = nn.Dropout(dropout)

    def forward(self, x, edge_index, edge_weight):
        h = self.t(x)
        h = self.s(h, edge_index, edge_weight)
        h = self.a(h)
        return self.norm(x + self.drop(h))


class STGNN(nn.Module):
    def __init__(self, num_nodes, edge_index, edge_weight, in_dim=2, input_len=12, horizon=12, channels=32,
                 num_blocks=3, cheb_k=3, adaptive=True, heads=4, dropout=0.1, kernel_size=3):
        super().__init__()
        self.register_buffer("edge_index", edge_index)
        self.register_buffer("edge_weight", edge_weight)
        self.inp = nn.Linear(in_dim, channels)
        self.blocks = nn.ModuleList([
            STBlock(channels, num_nodes, cheb_k, adaptive, heads, dropout, kernel_size, dilation=2 ** (i % 2))
            for i in range(num_blocks)])
        self.head = nn.Sequential(nn.Linear(input_len * channels, 2 * channels), nn.ReLU(),
                                  nn.Linear(2 * channels, horizon))

    def forward(self, x):  # x: (B,T,N,F) -> (B,horizon,N) in normalised units
        h = self.inp(x)
        for blk in self.blocks:
            h = blk(h, self.edge_index, self.edge_weight)
        B, T, N, C = h.shape
        h = h.permute(0, 2, 1, 3).reshape(B, N, T * C)
        return self.head(h).permute(0, 2, 1)

    def learned_adjacency(self):
        return [b.s.learned_adjacency() for b in self.blocks if b.s.adaptive]


# ------------------------------- baselines -------------------------------- #
class RNNForecaster(nn.Module):
    """Node-shared LSTM / GRU (no spatial information)."""

    def __init__(self, cell="lstm", in_dim=2, hidden=64, layers=2, horizon=12, dropout=0.1, **_):
        super().__init__()
        rnn = nn.LSTM if cell == "lstm" else nn.GRU
        self.rnn = rnn(in_dim, hidden, layers, batch_first=True, dropout=dropout if layers > 1 else 0.0)
        self.head = nn.Linear(hidden, horizon)

    def forward(self, x):
        B, T, N, F_ = x.shape
        h, _ = self.rnn(x.permute(0, 2, 1, 3).reshape(B * N, T, F_))
        return self.head(h[:, -1]).reshape(B, N, -1).permute(0, 2, 1)


class TransformerForecaster(nn.Module):
    """Node-shared temporal Transformer encoder (no spatial information)."""

    def __init__(self, in_dim=2, input_len=12, d_model=64, heads=4, layers=2, horizon=12, dropout=0.1, **_):
        super().__init__()
        self.inp = nn.Linear(in_dim, d_model)
        self.pos = nn.Parameter(torch.randn(1, input_len, d_model) * 0.02)
        layer = nn.TransformerEncoderLayer(d_model, heads, 4 * d_model, dropout, batch_first=True, norm_first=True)
        self.enc = nn.TransformerEncoder(layer, layers, enable_nested_tensor=False)
        self.head = nn.Linear(input_len * d_model, horizon)

    def forward(self, x):
        B, T, N, F_ = x.shape
        h = self.enc(self.inp(x.permute(0, 2, 1, 3).reshape(B * N, T, F_)) + self.pos)
        return self.head(h.reshape(B * N, -1)).reshape(B, N, -1).permute(0, 2, 1)


def build_model(name: str, cfg: dict, num_nodes: int, edge_index, edge_weight) -> nn.Module:
    d, m = cfg["data"], dict(cfg.get("model", {}))
    common = dict(in_dim=2, input_len=d["input_len"], horizon=d["horizon"])
    if name == "stgnn":
        return STGNN(num_nodes, edge_index, edge_weight, **common, **m)
    if name == "stgnn_fixed":  # ablation: no learned adjacency
        m["adaptive"] = False
        return STGNN(num_nodes, edge_index, edge_weight, **common, **m)
    if name in ("lstm", "gru"):
        return RNNForecaster(name, **common, hidden=m.get("channels", 64) * 2)
    if name == "transformer":
        return TransformerForecaster(**common, d_model=m.get("channels", 64) * 2)
    raise ValueError(name)
