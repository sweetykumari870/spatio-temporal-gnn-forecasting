import json
import os
import random
import subprocess
import time

import numpy as np
import torch
import yaml


def set_seed(seed: int, deterministic: bool = False):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = deterministic
    torch.backends.cudnn.benchmark = not deterministic


def load_config(path: str, overrides=()):
    """YAML config with ``a.b=value`` command-line overrides (values parsed as YAML)."""
    with open(path) as f:
        cfg = yaml.safe_load(f)
    for o in overrides:
        key, val = o.split("=", 1)
        node = cfg
        *parts, last = key.split(".")
        for p in parts:
            node = node.setdefault(p, {})
        node[last] = yaml.safe_load(val)
    return cfg


def git_hash() -> str:
    try:
        return subprocess.check_output(["git", "rev-parse", "--short", "HEAD"], stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "unknown"


class RunLogger:
    """Per-run directory with config snapshot, JSONL metrics log and environment info."""

    def __init__(self, root: str, name: str, cfg: dict):
        self.dir = os.path.join(root, f"{name}_{time.strftime('%Y%m%d-%H%M%S')}")
        os.makedirs(self.dir, exist_ok=True)
        with open(os.path.join(self.dir, "config.yaml"), "w") as f:
            yaml.safe_dump(cfg, f)
        env = dict(torch=torch.__version__, cuda=torch.version.cuda, git=git_hash(),
                   gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu")
        with open(os.path.join(self.dir, "env.json"), "w") as f:
            json.dump(env, f, indent=2)
        self.log_path = os.path.join(self.dir, "log.jsonl")

    def log(self, **kw):
        with open(self.log_path, "a") as f:
            f.write(json.dumps(kw) + "\n")
        print(" | ".join(f"{k}={v:.4f}" if isinstance(v, float) else f"{k}={v}" for k, v in kw.items()), flush=True)

    def save_json(self, name: str, obj):
        with open(os.path.join(self.dir, name), "w") as f:
            json.dump(obj, f, indent=2)
